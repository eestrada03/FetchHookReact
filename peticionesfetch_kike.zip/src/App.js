import React from "react";
import Header from "./componentes/header.js";
import Body from "./componentes/body.js";
import Menu from "./componentes/menu.js";
import Fetch from "./componentes/fetch.js";

function App() {
  return (
    <div>
      <Fetch />
    </div>
  );
}
export default App;
