import React from "react";
import Producto from "./Producto";

function Body() {
  return (
    <div>
      <Producto />
    </div>
  );
}

export default Body;
